package com.example.dung.applabit.main.findfriend

class FindFriendModel {

    fun inserLocation(latitude: Double, longitude: Double) {


    }
}