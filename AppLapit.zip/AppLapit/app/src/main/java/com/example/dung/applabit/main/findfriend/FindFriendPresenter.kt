package com.example.dung.applabit.main.findfriend

class FindFriendPresenter {

    fun inserLocation(latitude: Double, longitude: Double) {

    }
}