package com.example.dung.applabit.base

abstract class BasePresenter {
    abstract fun onDestroy()

}